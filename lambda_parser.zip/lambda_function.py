from PyPDF2 import PdfReader
import json
import boto3
from io import BytesIO

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Prepared')


def lambda_handler(event, context):
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    pdf_key = event['Records'][0]['s3']['object']['key']

    pdf_file = s3.get_object(Bucket=bucket_name, Key=pdf_key)
    pdf_content = pdf_file['Body'].read()

    pdf_io = BytesIO(pdf_content)

    parsed_text = extract_text_from_pdf(pdf_io)

    response = table.put_item(
        Item={
            'PacientName': 'PacientName',
            'EMail': 'EMail',
            'INR': parsed_text
        }
    )

    return {
        'statusCode': 200,
        'body': json.dumps('Successfully processed and stored PDF data.')
    }


def extract_text_from_pdf(pdf_io):
    reader = PdfReader(pdf_io)
    text = ''
    for page in reader.pages:
        text += page.extract_text()
    for line in text.split("\n"):
        if "INR" in line:
            try:
                result = float(line.split(":")[1].replace(",", "."))
                print("Result", result)
                return str(result)
            except BaseException as b_e:
                pass

